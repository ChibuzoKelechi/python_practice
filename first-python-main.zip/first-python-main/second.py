#Strings
#Variables
import random 
name = "Valentine"
lang = 'Python'
_pass =  'haha5'
_affirm = 'I am a {} in {}'

#Dashboard

print(name[0:3])
print(not lang[::-1])
print(name.capitalize())
print(name.count('n'))
print(name.find('i'))
print(_pass.isalnum())
print(_pass.isalpha())
print(_pass.isnumeric())
print(_pass.isidentifier())

#_word = input('Word:  ')
#_revword = _word[::-1]
#print(_affirm.format('programmer', _word))
#print(_revword)


#Lists
_cart =['Laptop', 'Pi', 'Flash drive']
_myPC, _chip, *rest = _cart
rev = _cart[::-1]
_cart[1]='M2'
_check = 'M2' in _cart
_list = _cart.append('Modem')
_cart.insert(2, 'Samsung')
_cart.remove('Flash drive')
del _cart[3]
_bag = _cart.copy()
_cart.clear()
_apps = ['Vscode', 'Pycharm', 'Safari', 'Google']
_Os = ['MacOS', 'Windows']
_desktop = _apps + _Os
_apps.extend(_Os)
_desktop.reverse()
_desktop.sort()
_order = sorted(_apps)

#Dashboard

print(_myPC)
print(rev)
print(_cart)
print(_check)
print(_bag)
print(_apps)
print(_desktop)
print(_order)


#Tuples
_tpl = tuple()
_desktop = ('Macbook', 'Thinkpad')
_table = list(_desktop)
_software = ('PyCharm', 'VsCode')
_combo = _desktop + _software

#dash
print(_table)
print('Macbook' in _desktop)
print(_software)
print(_combo)

#Set
best_snacks = {'Digestive', 'Cake', 'Bread'}
favorite_meal = {'Rice', 'Achicha'}
_set = {'Google', 'Slack', 'Maps'}
_basket = {'Biscuit', 'Apple', 'Maps'}
#_addon = input('app:  ')
_set.add('Github')
_set.intersection(_basket)
_box = _set.union(_basket)
#
print(_set)
print(_set.pop())
print(_set.intersection(_basket))
print(_basket.issubset(_set))
print(_basket.difference(_set))
print(_basket.isdisjoint(_set))

_set.update(_basket)
print(_box)
del _set
_basket.clear()
fact = 'Cake' in best_snacks

if fact:
    print('Of course')
best_animations = {'iOS', 'MacOS'}
best_mobile_os = {'OneUI', 'iOS'}
next_devices = {
'mobile':'Samsung Galaxy',
'laptop': ['Elitebook/Thinkpad', 'Macbook']
}