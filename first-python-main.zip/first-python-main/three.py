#Dictionaries
_user = {
'name': 'John',
'age': 17,
'pc': 'Thinkpad',
'country': 'US',
'married': False,
'job':'Fullstack developer'
}
user_2 = _user.copy() 
user_2['name'] = 'Mike'

special_features = ['Fast']

_laptop= {
'name':'Macbook',
'chip':'M2',
'os': 'MacOS Ventura',
'producer': 'Apple',
'advant': special_features
}
_laptop['advant'].append('super light')
_laptop['transfer'] = 'Airdrop'
_laptop['name'] = 'Macbook Air'
_user.items()
features = _laptop.keys()
user_2.pop('married')
_user.popitem()
del _user['married']

#Dock
print(_user)
print(_user['pc'])
print(_laptop['os'])
print(_laptop)
print(_laptop.get('chip'))
print('transfer' in _laptop)
#print(_user.items())
print(user_2)
print(features)

#Conditionals
a = 17 > 20
k = 3
_score = 9

if a:
    print('Correct')
else:
    print('False')
    
print('True') if  k >= 3 else print('Fail')

if k < 4:
    print('Is less than 4')
elif k < 0:
    print('Negative no.')
else:
    print('Greater')

if _score < 10 and _score <= 5:
    print('Pass')
elif _score > 8:
    print('Excellent')
else:
    print('Good')
    
if _score >= 9 or _score <= 2:
    print('Ends')
else:
    print('Middle')

_passkey = input('key:  ')
user_name = input('Username:   ')
_len = len(_passkey)
_auth = _passkey.isalpha()
_digit = _passkey.isnumeric()
name_len = len(user_name)
#print(_len)

if _len > 6 and _auth or _digit:
    print('Access Granted')
else:
    print('Access denied')
    
if name_len >= 2:
    print('Access granted')
else:
    print('Intruder💀')

#Loops
#While loops
_goals = 0
while _goals < 3:
    print('this is fine')
    _goals = _goals + 1
else:
    print('Damn😭🤣')  

_likes = 0
while _likes < 10:
    print(_likes, 'up')
    _likes = _likes + 1
    if _likes == 3:
        break

_lines = 0  
while _lines < 6:  
    if _lines == 3:
        _lines = _lines + 1
        continue
    print(_lines)
    _lines = _lines + 1

#For loop
tech_skills = ['React', 'Javascript', 'NextJS', 'React Native', 'Python']

for skill in tech_skills:
    print('I will master ', skill)
    
skill_set = {
'Appdev' : 'React native',
'Web-app': 'React/NextJs',
'Backend': 'Python'
}

for unit, tech in skill_set.items():
     print(unit, ':',tech)
     
_lengths = [2, 3, 5, 7, 6]
for length in _lengths:
    print(length)
    if length == 5:
        break
  
print('.         ')
      
file_nos = [1, 4, 7, 3, 9, 2]
for file in file_nos:
   if file == 3:
       continue
   print(file) 
else:
    print('Ended')

print('.        ') 
for no in range(0, 7):
    pass

for num in range(2, 9, 2):
    print(num)

print('Break')

#Multiplication table
digits = [0, 1, 2, 3, 4, 5, 6, 8]

for number in range(12):
    product = number * number
    print(number, '×',number, '=', product)