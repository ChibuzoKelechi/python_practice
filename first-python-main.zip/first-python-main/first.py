print('Hello world')

#Variables
first = "Peace"
_friends = ' Valerian, Ike,Kelechi, Peace'
k = 'I am learning JavaScript and Python'
num = 363
my_list = ['python', 'Javascript', 17, 'AI', 'Fullstack dev']
firstTuple = ('React', 'Python', 'IoT', 'NextJs')
_gravity = 9.81
_user = {
'name': 'Kelechi',
'age': 17,
'skill': 'Fullstack dev'
}
laptop, OS, chip = 'Macbook', 'MacOs Sonoma', 'M2'
is_smart = True 

#functions
def my_first():
    print('Python is awesome 😎')

def area_calc(radius):
    _pi = 3.142
    _area = (radius**2)*_pi
    print(_area)

my_first()

#dashboard
print( _friends)
print(17+17)
print(4//3)
print(2**4)
print (3*7)
#print (type(first))
print(my_list)
print(type(my_list))
#print(firstTuple)
print((2*3)+(3**2))
print(0.5*20, ' ', 0.2*50)
print(int(_gravity))
print(_user)
print(type(_user))
print(laptop, OS, chip)

#Circle area
area_calc(2)

print(3>2)
print(not is_smart)

_age = input('Age: ')
print('Yoru age is' + _age)