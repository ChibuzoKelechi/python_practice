# first-python

Since I will be using Python for backend development, I started learning the basics of python👾 

So everyday I will upload a file containing what i learnt for the day😌
